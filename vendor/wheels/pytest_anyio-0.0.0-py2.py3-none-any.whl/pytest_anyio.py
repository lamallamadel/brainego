"""
The pytest anyio plugin is built into anyio. You don't need this package.
"""

__version__ = "0.0.0"
