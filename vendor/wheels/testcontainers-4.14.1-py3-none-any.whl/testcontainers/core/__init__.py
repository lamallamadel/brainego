from .config import testcontainers_config

__all__ = ["testcontainers_config"]
